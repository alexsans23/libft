*Este proyecto ha sido creado como parte del currículo de 42 por acandrea.*

# Get Next Line 📖

> Una función en C diseñada para leer contenido de un descriptor de archivo **línea a línea**, de manera eficiente y sin cargar todo el documento en la memoria del sistema.

---

## 💡 El reto del proyecto

Cuando trabajamos en C, la función del sistema `read()` solo nos permite extraer **bloques fijos de bytes**, obligándonos a gestionar manualmente los saltos de línea. `get_next_line` nace para solucionar esto. 

Cada vez que se invoca la función, esta busca y retorna la siguiente línea disponible (incluyendo el carácter `\n`, excepto si el archivo termina de golpe). Al alcanzar el final del documento o detectar un fallo, retorna `NULL`.

La clave del algoritmo es el uso de una **variable estática**, la cual actúa como un contenedor persistente que retiene los bytes sobrantes entre una llamada y otra para evitar pérdidas de información.

```c
char *get_next_line(int fd);
```

### Valores de retorno
* **`char *` (La línea):** Si todavía queda texto disponible por procesar.
* **`NULL`:** Al llegar al término del archivo (EOF) o si ocurre un error de lectura/memoria.

⚠️ **Limitaciones del proyecto:** El código está desarrollado utilizando estrictamente `read`, `malloc` y `free`. No se permite el uso de variables globales, la función `lseek` ni herramientas de la `libft`.

---

## 🛠️ Compilación y Modo de Empleo

Este repositorio no incluye un archivo `Makefile` por requisitos del proyecto. Para probar la función, se debe compilar junto a un archivo `main.c` propio, definiendo el tamaño del búfer mediante la bandera `-D BUFFER_SIZE=n`.

```bash
# Ejemplo de compilación estándar con un main de pruebas:
cc -Wall -Werror -Wextra -D BUFFER_SIZE=42 get_next_line.c get_next_line_utils.c main.c -o gnl

# Ejecución:
./gnl
```

* Si se omite la bandera `-D BUFFER_SIZE`, el código fuente asigna un tamaño predeterminado de 42.
* Al ser una función auxiliar, requiere interactuar con un flujo de datos externo. Puede procesar tanto archivos del sistema (vía `open`) como la entrada estándar por terminal (`fd 0`).

---

## ⚙️ Arquitectura Interna

El programa sigue el principio de responsabilidad única, dividiendo el problema en subtareas especializadas:

| Componente | Propósito y Comportamiento |
| :--- | :--- |
| `get_next_line` | Modula el flujo principal del programa y gestiona la persistencia de la variable estática. |
| `ft_read` | Realiza las lecturas del archivo y acumula los bytes en el contenedor hasta dar con un `\n` o el fin del texto. |
| `extract_line` | Aísla y extrae los caracteres que conforman la línea actual para su devolución. |
| `update_stash` | Limpia el contenedor estático, preservando únicamente el residuo posterior al `\n`. |
| `free_stash` | Sanita la memoria liberando el contenedor en caso de error y resetea el puntero. |
| `ft_strlen` / `ft_strchr` / `ft_strjoin` | Funciones auxiliares a medida para la manipulación de cadenas de texto. |

### Flujo lógico del algoritmo

1. **Lectura controlada:** Se leen fragmentos del tamaño de `BUFFER_SIZE` y se concatenan en la variable estática. La lectura se detiene inmediatamente al detectar un salto de línea para no consumir más recursos de los necesarios.
2. **Segmentación:** Se corta el fragmento correspondiente a la línea procesada (con su `\n`).
3. **Actualización:** El remanente que quedó tras el salto de línea se guarda en la variable estática para la próxima ejecución.
4. **Cierre:** Al vaciarse el flujo, se libera la memoria restante y se retorna `NULL`.

Este diseño garantiza estabilidad total sin importar el valor del `BUFFER_SIZE` (desde 1 hasta valores masivos), gestionando dinámicamente la memoria sin necesidad de alterar el puntero de lectura del archivo. Toda la memoria asignada dinámicamente se libera de manera estricta durante el proceso; el receptor de la línea es el único responsable de liberar el puntero final.

---

## 📚 Documentación y Herramientas

* **Manuales consultados:** `read(2)`, `malloc(3)`, `free(3)`.
* **Conceptos clave:** Ciclo de vida y alcance de las variables estáticas en C; manipulación de File Descriptors (FD) en sistemas UNIX.
* **Uso de Inteligencia Artificial:** Se utilizó asistencia de modelos de lenguaje para asimilar el comportamiento de la memoria estática.
