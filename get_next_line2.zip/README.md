*Este proyecto ha sido creado como parte del currículo de 42 por acandrea.*

# Get Next Line

## Descripción

En este proyecto he desarrollado `get_next_line`, una función que permite ir leyendo un archivo una línea cada vez. La idea es que cada llamada a la función devuelva una nueva línea del archivo, en lugar de tener que leer todo su contenido de golpe.

La función recibe como parámetro un **file descriptor** y devuelve un `char *` con la siguiente línea disponible. Cuando la línea contiene un salto de línea, este también forma parte de la cadena devuelta.

```c
char *get_next_line(int fd);
```

Por ejemplo, si el archivo contiene:

```text
Primera línea
Segunda línea
Tercera línea
```

varias llamadas consecutivas a `get_next_line` irán devolviendo cada una de esas líneas.

Cuando se ha llegado completamente al final del archivo y no queda nada pendiente, la función devuelve `NULL`.

Una de las partes nuevas que he tenido que trabajar en este proyecto es el uso de **variables estáticas**. Son necesarias porque entre una llamada y otra tengo que poder conservar parte de lo que ya ha leído `read()` pero todavía no he devuelto.

Las funciones que utilizo para realizar la lectura y gestionar la memoria son:

* `read()`
* `malloc()`
* `free()`

## Instrucciones

Este proyecto contiene una función y no un programa que pueda ejecutarse directamente. Para comprobar que funciona, hay que utilizarla desde un `main` de prueba.

La compilación se puede hacer directamente con `cc`. El valor de `BUFFER_SIZE` se puede cambiar desde la propia línea de compilación:

```bash
cc -Wall -Wextra -Werror -D BUFFER_SIZE=42 \
get_next_line.c get_next_line_utils.c main.c -o gnl
```

El número `42` del ejemplo se puede sustituir por otro valor para probar el comportamiento con diferentes tamaños de buffer.

Si el proyecto tiene definido un valor por defecto para `BUFFER_SIZE`, también se puede compilar sin especificarlo:

```bash
cc -Wall -Wextra -Werror \
get_next_line.c get_next_line_utils.c main.c -o gnl
```

Para hacer una prueba sencilla, puedo utilizar un `main` como este:

```c
#include "get_next_line.h"
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(void)
{
    int fd;
    char *line;

    fd = open("archivo.txt", O_RDONLY);
    while ((line = get_next_line(fd)) != NULL)
    {
        printf("%s", line);
        free(line);
    }
    close(fd);
    return (0);
}
```

Una vez compilado:

```bash
./gnl
```

También se puede probar utilizando la entrada estándar (`stdin`) si el descriptor utilizado en el `main` es `0`.

## Cómo funciona

La principal dificultad del proyecto está en que `read()` y las líneas no funcionan exactamente de la misma manera.

`read()` recibe un número de bytes y devuelve esos bytes. No se detiene automáticamente cuando encuentra un `\n`. Por eso, dependiendo del `BUFFER_SIZE`, una lectura puede encontrarse con situaciones diferentes:

* Puede contener exactamente una línea.
* Puede contener varias líneas.
* Puede quedarse a mitad de una línea.
* Puede contener una línea completa y además el comienzo de la siguiente.

Para solucionar esto, mantengo una cadena estática que utilizo como una especie de zona de almacenamiento temporal.

Primero voy haciendo lecturas mientras todavía no tengo una línea completa. Cada bloque que obtengo se añade a lo que ya tenía almacenado.

En cuanto encuentro un `\n`, ya tengo suficiente información para construir la línea que debo devolver. Busco ese primer salto de línea y separo la información en dos partes:

```text
[ línea que devuelvo ] [ contenido que todavía necesito ]
```

La primera parte se devuelve al usuario y la segunda se conserva para la siguiente llamada.

Por ejemplo, si después de una lectura tengo:

```text
Hola mundo\nEsta es otra línea\n
```

la primera llamada devuelve:

```text
Hola mundo\n
```

y conserva:

```text
Esta es otra línea\n
```

Cuando vuelva a llamar a la función, primero aprovecharé ese contenido antes de hacer lecturas innecesarias.

Si llego al final del archivo y queda contenido que no termina en `\n`, ese contenido también se considera una línea y se devuelve. Cuando ya no queda absolutamente nada, se libera la memoria pendiente y la función devuelve `NULL`.

## Elección del algoritmo

La decisión de utilizar una **variable estática para guardar el contenido sobrante** viene principalmente de la forma en la que funciona el proyecto.

Necesito que cierta información sobreviva cuando termina una llamada a `get_next_line`, porque es posible que `read()` haya leído más de lo necesario para la línea actual. Una variable local normal desaparecería al salir de la función y perdería esos datos.

Una variable global solucionaría este problema, pero no es una opción válida para el proyecto. Por eso utilizo una variable `static` local, que mantiene su contenido entre llamadas pero sigue estando limitada al ámbito donde la utilizo.

También decidí ir leyendo solamente hasta tener una línea completa. No tendría sentido leer todo el archivo cuando solamente se necesita devolver una línea. Además, esto permite que el comportamiento sea correcto con `BUFFER_SIZE` pequeños, grandes o incluso con valores extremos.

Otra parte importante del algoritmo es que no necesito mover el descriptor de archivo hacia atrás. Si una lectura contiene más información de la que necesito en ese momento, simplemente guardo el sobrante en memoria y lo utilizo posteriormente.

### Gestión de memoria

La gestión de memoria también es una parte importante de la implementación.

Cada vez que creo espacio dinámico para almacenar o construir una cadena, tengo que controlar cuándo deja de ser necesario. En ese momento utilizo `free()` para evitar fugas de memoria.

La cadena que devuelve `get_next_line` es responsabilidad de quien utiliza la función. Por eso, después de procesar cada línea, el programa que la ha llamado debe liberar esa memoria.

## Recursos

Para entender y desarrollar el proyecto he utilizado diferentes fuentes relacionadas con C y con la lectura de archivos:

* `man 2 read` para consultar el comportamiento de `read()` y sus valores de retorno.
* `man 3 malloc` para revisar la reserva dinámica de memoria.
* `man 3 free` para consultar la liberación de memoria.
* Documentación sobre **file descriptors** y el funcionamiento de `stdin`.
* Material sobre **variables estáticas en C** y su duración entre llamadas a una función.

### Uso de IA

He utilizado herramientas de IA como apoyo durante el desarrollo, principalmente cuando tenía dudas sobre conceptos concretos del proyecto.

Por ejemplo, las he utilizado para entender mejor cómo funcionan las variables estáticas, aclarar el comportamiento de `read()` dependiendo del `BUFFER_SIZE` y plantear casos que podían dar problemas durante las pruebas.

También las he utilizado como ayuda para revisar la lógica general y pensar en diferentes situaciones límite, como un archivo vacío, una línea muy larga, un archivo que no termina en `\n` o diferentes tamaños de `BUFFER_SIZE`.

La IA ha sido utilizada como herramienta de apoyo y consulta, no como sustituto de la comprensión del proyecto. El código, las decisiones tomadas y la explicación del funcionamiento son responsabilidad mía y debo poder defenderlos y explicarlos durante la evaluación.
